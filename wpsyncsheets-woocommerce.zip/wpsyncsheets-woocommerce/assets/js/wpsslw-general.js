/**
 * Admin Enqueue Script
 *
 * @package     wpsyncsheets-woocommerce
 */

jQuery( document ).ready(
	function () {
		jQuery( '.wpsslw-support' ).parent().attr( 'target','_blank' );
	}
);
