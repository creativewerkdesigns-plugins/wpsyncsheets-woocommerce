<?php
/**
 * Main WPSyncSheetsWooCommerce namespace.
 *
 * @since 1.0.0
 * @package wpsyncsheets-woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; }

if ( ! class_exists( 'WPSSLW_Coupon_Utils' ) ) :
	/**
	 * Class WPSSLW_Coupon_Utils.
	 */
	abstract class WPSSLW_Coupon_Utils {


	}
endif;
