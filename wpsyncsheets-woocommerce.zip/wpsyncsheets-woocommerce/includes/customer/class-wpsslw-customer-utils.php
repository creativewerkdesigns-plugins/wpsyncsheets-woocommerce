<?php
/**
 * Main WPSyncSheetsWooCommerce namespace.
 *
 * @since 1.0.0
 * @package wpsyncsheets-woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; }

if ( ! class_exists( 'WPSSLW_Customer_Utils' ) ) :
	/**
	 * Class WPSSLW_Customer_Utils.
	 */
	abstract class WPSSLW_Customer_Utils {


	}
endif;
